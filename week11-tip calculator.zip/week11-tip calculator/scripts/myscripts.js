"use strict";
// When the user selects a tip percentage, 
// var tipamount= Number(document.getElementById("tips").value);
document.getElementById("submitbutton").onclick=tipCalculator;
function tipCalculator () {
    
    var bill=Number(document.getElementById("bill2").value);
    var tipPercentage=Number(document.getElementById("tips").value);
    console.log(tipPercentage);
    var totaltip=Number((bill*tipPercentage).toFixed(2));
    console.log(totaltip);
    var totalbill=Number(bill+totaltip);
    // calculate the tip amount
    // display it in a paragraph that has a light blue background.
    document.getElementById("para1").innerHTML+=Number(totaltip.toFixed(2));
    // Calculate the total amount to be paid (including the tip)
// display it in a paragraph with a light green background.
    document.getElementById("para2").innerHTML+=totalbill.toFixed(2);
    console.log(totalbill);
       }

 






// var firstpercent=Number(document.getElementById("fifteen").innerHTML);
// var secondpercent=Number(document.getElementById("eightteen").innerHTML);
// var thirdpercent=Number(document.getElementById("twenty").innerHTML);
// document.getElementById("button2").onclick=bigspender;
